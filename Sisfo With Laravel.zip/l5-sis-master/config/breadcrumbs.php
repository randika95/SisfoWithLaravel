<?php

return [

	'view' => 'backend/templates/breadcrumbs',

];
